﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DataProvider
{
    public class PersonRepository
    {
        public static string TestV1 = "ABCV1";

        public static string TestV2 = "ABCV2";

        public static string TestV3 = "ABCV3";

        public static string TestV4 = "ABCV4";

        public static string TestV5 = "ABCV5";

        public static string TestV6 = "ABCV6";

        public static string TestV7 = "ABCV7";

        public static string TestV8 = "ABCV8";

        public static string TestV9 = "ABCV9";

        public static async Task<IEnumerable<Person>> GetPersonsAsync()
        {
            return await TaskEx.Run(() =>
            {
                return new int[] { 1, 2 }.Select(id => new Person() { Id = id, Name = "Name" + id.ToString() });
            }
            ).ConfigureAwait(false);
        }
    }

    public class Person
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
